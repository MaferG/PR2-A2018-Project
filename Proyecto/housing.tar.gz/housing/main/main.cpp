/**
 *  @name: Group Housing

 *  @members: Adolfo, Alejandro, Jorge, Cherry, Maria Fernanda
	
 *  @brief: Creation of class type housing

 *  @file: main.cpp
 * 
 * */
#include <housing.h>

int main(){

    ///Test of the default constructor
    Housing new_hou;
    std::cout<<"Housing number :   "<<new_hou.get_num_Housing() <<" \n";
    std::cout<<"Type  :  "<<new_hou.get_type_Housing()<<" \n";
    std::cout<<"Size  :  "<<new_hou.get_size()<<" \n";
    std::cout<<"Number of bedrooms :"<<new_hou.get_num_bedrooms()<<" \n";
    std::cout<<"Number of bathrooms :  "<<new_hou.get_num_bathrooms()<<" \n";
    std::cout<<"Maximun number of people : "<<new_hou.get_max_num_people()<<" \n";
    std::cout<<"Number of parking "<<new_hou.get_num_parking()<<" \n";
    std::cout<<"State :  "<<new_hou.get_state()<<" \n";
    std::cout<<"Valuation : "<<new_hou.get_valuation()<<" \n";
    std::cout<<"Direction :  "<<new_hou.get_address()<<" \n";
    std::cout<<"City  :   "<<new_hou.get_city()<<" \n";

    ///Test of the parametric contructor

    Housing other("apartament", 100.5, 3,1,3,1,"Merida", 12345,"Av 1 house x","Ejido");

    std::cout<<"\n\n\nHousing number :   "<<other.get_num_Housing() <<" \n";
    std::cout<<"Type  :  "<<other.get_type_Housing()<<" \n";
    std::cout<<"Size  :  "<<other.get_size()<<" \n";
    std::cout<<"Number of bedrooms :"<<other.get_num_bedrooms()<<" \n";
    std::cout<<"Number of bathrooms :  "<<other.get_num_bathrooms()<<" \n";
    std::cout<<"Maximun number of people : "<<other.get_max_num_people()<<" \n";
    std::cout<<"Number of parking "<<other.get_num_parking()<<" \n";
    std::cout<<"State :  "<<other.get_state()<<" \n";
    std::cout<<"Valuation : "<<other.get_valuation()<<" \n";
    std::cout<<"Direction :  "<<other.get_address()<<" \n";
    std::cout<<"City  :   "<<other.get_city()<<" \n";

    ///Test of the reference constructor

    Housing ref(change);

    std::cout<<"\n\n\nHousing number :   "<<ref.get_num_Housing() <<" \n";
    std::cout<<"Type  :  "<<ref.get_type_Housing()<<" \n";
    std::cout<<"Size  :  "<<ref.get_size()<<" \n";
    std::cout<<"Number of bedrooms :"<<ref.get_num_bedrooms()<<" \n";
    std::cout<<"Number of bathrooms :  "<<ref.get_num_bathrooms()<<" \n";
    std::cout<<"Maximun number of people : "<<ref.get_max_num_people()<<" \n";
    std::cout<<"Number of parking "<<ref.get_num_parking()<<" \n";
    std::cout<<"State :  "<<ref.get_state()<<" \n";
    std::cout<<"Valuation : "<<ref.get_valuation()<<" \n";
    std::cout<<"Direction :  "<<ref.get_address()<<" \n";
    std::cout<<"City  :   "<<ref.get_city()<<" \n";

    ///Test of modifiers

    Housing change;
    
    change.set_type_Housing("Habitacion");
    change.set_size(100.3);
    change.set_num_bedrooms(1);
    change.set_num_bathrooms(1);
    change.set_max_num_people(1);
    change.set_num_parking(1);
    change.set_state("Merida");
    change.set_valuation(9995);
    change.set_city("El Vigia");
    change.set_address("Calle el vigia");

    std::cout<<"\n\n\nHousing number :   "<<change.get_num_Housing() <<" \n";
    std::cout<<"Type  :  "<<change.get_type_Housing()<<" \n";
    std::cout<<"Size  :  "<<change.get_size()<<" \n";
    std::cout<<"Number of bedrooms :"<<change.get_num_bedrooms()<<" \n";
    std::cout<<"Number of bathrooms :  "<<change.get_num_bathrooms()<<" \n";
    std::cout<<"Maximun number of people : "<<change.get_max_num_people()<<" \n";
    std::cout<<"Number of parking "<<change.get_num_parking()<<" \n";
    std::cout<<"State :  "<<change.get_state()<<" \n";
    std::cout<<"Valuation : "<<change.get_valuation()<<" \n";
    std::cout<<"Direction :  "<<change.get_address()<<" \n";
    std::cout<<"City  :   "<<change.get_city()<<" \n";

    return 0;
}